package com.klef.jfsd.fds.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.fds.model.Admin;
import com.klef.jfsd.fds.model.User;
import com.klef.jfsd.fds.service.AdminService;
import com.klef.jfsd.fds.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class Projectcontroller {
	
	  @Autowired
	  private AdminService adminService;
	  @Autowired
	  private UserService userService;
 
	  @GetMapping("index")
		public String index() {
			return "index";
		}
		@GetMapping("login")
		public String login() {
			return "login";
		}
		@GetMapping("Register")
		public String register() {
			return "Register";
		}
		@GetMapping("product")
		public String product() {
			return "product";
		}
		@GetMapping("contact")
		public String contact() {
			return "contact";
		}
		@GetMapping("testimonial")
		public String testimonial() {
			return "testimonial";
		}
		@GetMapping("productview1")
		public String product1() {
			return "productview1";
		}
		@GetMapping("blog_list")
		public String blog() {
			return "blog_list";
		}
		@GetMapping("about")
		public String about() {
			return "about";
		}
	
	
	
	@PostMapping("checkuserlogin")
	  public ModelAndView checkuserlogin(HttpServletRequest request) 
	  {
	     ModelAndView mv = new ModelAndView();
	  
	       String username = request.getParameter("username");
	       String pwd = request.getParameter("pwd");
	       
	      User us =  userService.checkuserlogin(username, pwd);
	      
	      if(us!=null)
	      {
	        //session
	        
	        HttpSession session = request.getSession();
	        
	        session.setAttribute("eid", us.getId()); // eid is a session variable
	        session.setAttribute("eusername", us.getUsername()); // ename is a session variable
	        
	        //session
	        
	        mv.setViewName("userdashboard");
	        
	      }
	      else
	      {
	        mv.setViewName("error");
	      }
	    
	      return mv;
	  }
	
	
	
	@PostMapping("newuser")
	  public ModelAndView insertaction(HttpServletRequest request) 
	  {
	    String msg = null;
	    ModelAndView mv = new ModelAndView();
	    
	    try 
	    {
	      String username = request.getParameter("username");
	        String email = request.getParameter("email");
	        String pwd = request.getParameter("pwd");
	        String rpwd= request.getParameter("rpwd");
	        
	        System.out.println("i  am here ");
	      
	        if (rpwd.equals(pwd)) {
	          
	          User us = new User();
	        
	          us.setUsername(username);
	          us.setEmail(email);
	          us.setPassword(pwd);
	          us.setRpassword(rpwd);
	        
	          msg = userService.adduser(us);
	          mv.setViewName("login");
	          // 123 --> login--> register
	        }
	        else {
	              // Password and retype password do not match, show an error message.
	          
	          System.out.println("didnt enter loop");
	              mv.setViewName("error");
	          }
	    } 
	    catch (Exception e) 
	    {
	      msg = e.getMessage();
	      mv.setViewName("error");
	    }
	     
	    return mv;
	      
	  }
	
	@PostMapping("checkadminlogin")
	  public ModelAndView checkadminloginpage(HttpServletRequest request) 
	  {
	     ModelAndView mv = new ModelAndView();
	  
	    String auname = request.getParameter("auname");
	      String apwd = request.getParameter("apwd");
	       
	      Admin admin = adminService.checkadminlogin(auname, apwd);
	      
	      if(admin!=null)
	      {
	        
	        mv.setViewName("admindashboard");
	        
	      }
	      else
	      {
	        mv.setViewName("error");
	      }
	    
	      return mv;
	  }
	
}
