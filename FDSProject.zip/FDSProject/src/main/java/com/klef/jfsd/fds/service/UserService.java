package com.klef.jfsd.fds.service;

import com.klef.jfsd.fds.model.User;

public interface UserService {
  
  public String adduser(User us);
  public User checkuserlogin(String username,String pwd);

}