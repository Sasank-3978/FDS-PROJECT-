package com.klef.jfsd.fds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FdsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FdsProjectApplication.class, args);
		System.out.println("Your Project is running.......");
	}

}
