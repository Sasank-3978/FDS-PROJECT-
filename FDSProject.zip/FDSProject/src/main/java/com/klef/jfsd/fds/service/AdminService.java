package com.klef.jfsd.fds.service;


import com.klef.jfsd.fds.model.Admin;

public interface AdminService 
{
  public Admin checkadminlogin(String auname, String apwd);

}
