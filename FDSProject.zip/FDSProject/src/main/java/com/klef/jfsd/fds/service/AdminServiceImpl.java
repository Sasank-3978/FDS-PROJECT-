package com.klef.jfsd.fds.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.fds.model.Admin;
import com.klef.jfsd.fds.repository.AdminRepository;



@Service
public class AdminServiceImpl implements AdminService
{
    @Autowired
  private AdminRepository adminRepository;
    
  @Override
  public Admin checkadminlogin(String auname, String apwd) {
    
    return  adminRepository.checkadminlogin(auname, apwd);
  }

}