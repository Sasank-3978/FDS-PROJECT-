package com.klef.jfsd.fds.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.klef.jfsd.fds.model.User;
import com.klef.jfsd.fds.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService
{
    @Autowired
  private UserRepository userRepository;
    
    @Override
  public String adduser(User us) {
    
    userRepository.save(us);
    
    return "User Registered Sucessfully";
  }

  @Override
  public User checkuserlogin(String username, String pwd) {
    
    
    return userRepository.checkuserlogin(username, pwd);
  }

}