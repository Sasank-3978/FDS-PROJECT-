package com.klef.jfsd.fds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FdsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
